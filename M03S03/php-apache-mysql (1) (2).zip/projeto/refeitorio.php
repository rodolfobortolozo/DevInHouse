<html>
<head>
<title>Sistema Refeit�rio</title>
<link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>

<body>






<div id="quadro2">
<img src="../projeto/logo.svg">

<nav id="menu">
<ul>
	<li><a href="../projeto/selecionaEntrada.php"><h1>REGISTRAR REFEI��ES</h1></a></li>
	
	
	<li><a href="../projeto/refeitorioRelatorio.php"><h1>RELATORIOS</h1></a></li>
</ul>
</nav>
</div>




</body>
</html>
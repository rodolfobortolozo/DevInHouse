<?
define('DB_HOSTNAME', '192.168.0.20');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'rootdb__');
define('DB_DATABASE', 'refeitorio');


?>

<html>

<head>
<title> Relat�rio Programa��o </title>
<link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>

<body>
<div id="quadro">
<img src="../projeto/logo.svg">
<h1>Programa��o para o Dia</h1>
<form id="qual-dia" name="qual-id" method="post" onsubmit="validaForm(); return false;" action="gerandoRelatorio.php">
<p>DATA:
<select name="dia">
<option selected>01
<option value="02">02
<option value="03">03
<option value="04">04
<option value="05">05
<option value="06">06
<option value="07">07
<option value="08">08
<option value="09">09
<option value="10">10
<option value="11">11
<option value="12">12
<option value="13">13
<option value="14">14
<option value="15">15
<option value="16">16
<option value="17">17
<option value="18">18
<option value="19">19
<option value="20">20
<option value="21">21
<option value="22">22
<option value="23">23
<option value="24">24
<option value="25">25
<option value="26">26
<option value="27">27
<option value="28">28
<option value="29">29
<option value="30">30
<option value="31">31
</select>
/
<select name="mes">
<option selected>01
<option value="02">02
<option value="03">03
<option value="04">04
<option value="05">05
<option value="06">06
<option value="07">07
<option value="08">08
<option value="09">09
<option value="10">10
<option value="11">11
<option value="12">12
</select> / 2016
<p><input type="submit" value="Confirmar" />
</form>


<a href="../projeto/refeitorio.php">Voltar ao Menu Principal</a>
</div>

</body>


</html>
<html>
<head>
<title>Sistema Refeit�rio</title>
<link rel="stylesheet" href="style.css" type="text/css" media="all" />
</head>

<body>

<div id="quadro">
<img src="../projeto/logo.svg">
<center>
<h1> Registro de Usu�rios </h1>
</center>
<nav id="menu">
<ul>
	<li><a href="../projeto/cadastro.php">Cadastrar Usu�rio</a></li>
	
	
	
	
</ul>

</nav>
</div>




<div id="quadro2">
<img src="../projeto/logo.svg">
<center>
<h1> Relat�rios </h1>
</center>
<nav id="menu">
<ul>
	<li><a href="../projeto/recebeDia.php">Todas as Refei��es de um Dia</a></li>
	
	
	
	
</ul>
</nav>
</div>

<div id="quadro2">
<img src="../projeto/logo.svg">
<center>
<h1> Pedido </h1>
</center>
<nav id="menu">

</nav>
<br>
<a href="../projeto/refeitorio.php">Voltar ao Menu Principal</a>

</div>




</body>
</html>